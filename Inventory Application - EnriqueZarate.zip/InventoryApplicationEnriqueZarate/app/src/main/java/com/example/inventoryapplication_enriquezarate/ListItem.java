package com.example.inventoryapplication_enriquezarate;

public class ListItem {
    private String itemName;
    private int itemAmount;

    public ListItem(String itemName, int itemAmount){
        this.itemName = itemName;
        this.itemAmount = itemAmount;
    }

    public String getItemName() {
        return itemName;
    }

    public int getItemAmount() {
        return itemAmount;
    }
}

