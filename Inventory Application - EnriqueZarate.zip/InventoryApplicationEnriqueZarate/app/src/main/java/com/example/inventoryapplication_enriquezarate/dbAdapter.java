package com.example.inventoryapplication_enriquezarate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class dbAdapter extends RecyclerView.Adapter<dbAdapter.listViewHolder> {

    private Context mCtx;
    private List<ListItem> itemlist;
    private OnItemClickListener listener;
    private InventoryDatabase myDB;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener clickListener){
        listener = (OnItemClickListener) clickListener;
    }

    public dbAdapter(Context mCtx, List<ListItem> itemlist) {
        this.mCtx = mCtx;
        this.itemlist = itemlist;
    }

    @NonNull
    @Override
    public listViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.recycler_view_item, null);
        return new listViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull listViewHolder holder, int position) {
        ListItem listItem = itemlist.get(position);
        holder.itemName.setText(listItem.getItemName());
        holder.itemQuantity.setText(String.valueOf(listItem.getItemAmount()));


    }

    @Override
    public int getItemCount() {
        return itemlist.size();
    }

    class listViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView itemQuantity;
        ImageButton deleteButton;
        ImageButton editButton;

        public listViewHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.quantityValue);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClick(getAdapterPosition());
                    String name = itemName.getText().toString();
                    String number = itemQuantity.getText().toString();
                    InventoryDatabase myDB = new InventoryDatabase(mCtx);
                    myDB.deleteItem(name);

                }
            });

        }
    }


}
