package com.example.inventoryapplication_enriquezarate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    UserDatabase myDB;
    Button btnRegister, btnView;
    EditText editText;
    EditText editText2;
    Button btnLogin, btnView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.editTextTextPersonName);
        editText2 = (EditText) findViewById(R.id.editTextTextPassword);
        btnRegister = (Button) findViewById(R.id.registerButton);
        btnView = (Button) findViewById(R.id.registerButton);
        myDB = new UserDatabase(this);
        btnLogin = (Button) findViewById(R.id.loginButton);
        btnView2 = (Button) findViewById(R.id.loginButton);




        btnView2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String user = editText.getText().toString();
                String pass = editText2.getText().toString();

                if(user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Please enter something in all fields.", Toast.LENGTH_LONG).show();
                }
                else {
                    Boolean checkuser = myDB.checkusernamepassword(user, pass);
                    if (checkuser==true) {
                        Toast.makeText(MainActivity.this, "Sign in Successful", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent (MainActivity.this, ViewGridLayout.class);
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Login Failed.", Toast.LENGTH_LONG).show();

                    }
                }

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newEntry = editText.getText().toString();
                String newPassword = editText2.getText().toString();
                if (editText.length() != 0) {
                    AddData(newEntry, newPassword);
                    editText.setText("");
                    editText2.setText("");
                }
                else {
                    Toast.makeText(MainActivity.this, "You need to add something to this field", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void AddData(String newEntry, String newPassword) {
        boolean insertData = myDB.addUser(newEntry, newPassword);

        if (insertData == true) {
            Toast.makeText(MainActivity.this, "New User Registered", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(MainActivity.this, "Error: User was not added.", Toast.LENGTH_LONG).show();
        }
    }
}

