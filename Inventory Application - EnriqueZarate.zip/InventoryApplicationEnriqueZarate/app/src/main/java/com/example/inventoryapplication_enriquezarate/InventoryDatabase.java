package com.example.inventoryapplication_enriquezarate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEMNAME = "itemname";
        private static final String COL_QUANTITY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEMNAME + " text, " +
                InventoryTable.COL_QUANTITY + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public boolean addItem(String itemName, String quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(InventoryTable.COL_ITEMNAME, itemName);
        contentValues.put(InventoryTable.COL_QUANTITY, quantity);

        long result = db.insert(InventoryTable.TABLE, null, contentValues);

        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public Cursor getListContents() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + InventoryTable.TABLE,null);
        return data;
    }

    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(InventoryTable.COL_ITEMNAME, itemName);
        //contentValues.put(InventoryTable.COL_QUANTITY, quantity);

        long result = db.delete(InventoryTable.TABLE, "itemname=?", new String[]{itemName});

        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }



}
