package com.example.inventoryapplication_enriquezarate;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;


public class AdditionFragment extends Fragment {

    View view;
    Button addButton, addButtonView;
    EditText itemName;
    EditText itemQuantity;
    InventoryDatabase myDB;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_addition, container, false);
        addButton = (Button)view.findViewById(R.id.AddItemFragment);
        addButtonView = (Button)view.findViewById(R.id.AddItemFragment);
        itemName = (EditText)view.findViewById(R.id.editTextItemName);
        itemQuantity = (EditText)view.findViewById(R.id.editTextItemQuantity);


        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newEntry = itemName.getText().toString();
                String newQuantity = itemQuantity.getText().toString();
                if (itemName.length() != 0) {
                    AddItem(newEntry, newQuantity);
                    itemName.setText("");
                    itemQuantity.setText("");
                }
                else {
                    Toast.makeText(getActivity(), "You need to add something to this field", Toast.LENGTH_LONG).show();
                }
            }
        });

        return view;

    }

    public void AddItem(String newEntry, String newQuantity) {
        InventoryDatabase myDB = new InventoryDatabase(getContext());
        boolean insertData = myDB.addItem(newEntry, newQuantity);

        if (insertData == true) {
            Toast.makeText(getActivity(), "Item Added", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(getActivity(), "Error: Item was not added.", Toast.LENGTH_LONG).show();
        }
    }


}