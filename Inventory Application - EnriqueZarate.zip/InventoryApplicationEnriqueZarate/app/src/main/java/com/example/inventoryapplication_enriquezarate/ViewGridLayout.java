package com.example.inventoryapplication_enriquezarate;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ViewGridLayout extends AppCompatActivity {


    RecyclerView recyclerView;
    dbAdapter adapter;
    ImageButton btnAdd, btnAddView, smsnotification;

    List<ListItem> itemList;

    InventoryDatabase myDB;


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        setContentView(R.layout.gridlayout);

        itemList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.recycleView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        btnAdd = (ImageButton) findViewById(R.id.addbutton);
        btnAddView = (ImageButton) findViewById(R.id.addbutton);
        smsnotification = (ImageButton) findViewById(R.id.smsnotification);
        myDB = new InventoryDatabase(this);
        adapter = new dbAdapter(this, itemList);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new dbAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                itemList.remove(position);
                adapter.notifyItemRemoved(position);

            }
        });

        updateDatabase();

        btnAddView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                replaceFragment(new AdditionFragment());
            }
        });

        smsnotification.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                replaceFragment(new SMSNotificationFragment());
            }
        });



    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.fragment);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        if (fragment != null) {
            updateDatabase();
            fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.remove(fragment);
            fragmentTransaction.commit();
        }
        else {
            super.onBackPressed();
        }
    }

    public void updateDatabase() {
        Cursor data = myDB.getListContents();
        itemList.clear();

        if (data.moveToFirst()){
            do {
                itemList.add(new ListItem(data.getString(1),
                        data.getInt(2)));
            }while (data.moveToNext());
        }
        data.close();
        recyclerView.setAdapter(adapter);

    }

}
